# MRK — Design System Global
## Voice is an Asset. · Version 1.0 · Avril 2026

---

## 01 — Fondations de marque (invariants)

Ces éléments ne changent **jamais**, quelle que soit la plateforme.

### Slogan
> **Voice is an Asset.**
Langue unique : anglais. Inchangé sur toutes les plateformes.

### Positionnement
MRK est l'intersection rare entre l'autorité éditoriale, une culture médicale et scientifique solide, et une agilité de production sans compromis — pour les marques et les individus qui comprennent que la voix est un actif stratégique, pas une option.

### Dénominations validées
| Usage | Formulation correcte | Formulation interdite |
|---|---|---|
| Titre de poste | Pro de la Voix | Opérateur vocal |
| Langue arabe | Algerian Arabic | Darija |
| Parcours | Mon parcours est atypique | Mon profil est rare |
| Stack tech | Agilité de production | Clone vocal / ElevenLabs |
| Formation | Culture médicale | Années d'études médicales |

### Langues de communication
- **Arabe** → marché local B2B algérien
- **Français** → marché francophone / international
- **Anglais** → marché international / e-learning / slogan universel
- Règle : jamais mélangées dans un même contenu

---

## 02 — Typographie (toutes plateformes)

| Rôle | Police | Graisse | Usage |
|---|---|---|---|
| Display / Titres H1 | Playfair Display | 700 | Héros, accroches, slogans |
| Titres H2–H3 | Playfair Display | 400 | Sous-titres, noms d'offres |
| Accent éditorial | Playfair Display | 400 italic | Citations, formules-clés |
| Corps de texte | DM Sans | 300 | Paragraphes, descriptions |
| Labels / Navigation | DM Sans | 500 | Uppercase, letter-spacing 2.5px |
| Code / Références | DM Mono | 400 | URLs, données techniques |

**Règle absolue :** deux familles maximum. Jamais de troisième police dans les supports MRK.

---

## 03 — Couleurs communes (toutes versions)

### Fond abyssal (base partagée)
| Token | Hex | Usage |
|---|---|---|
| `--n` | `#060A10` | Fond principal |
| `--c1` | `#0B1018` | Fond secondaire |
| `--c2` | `#101828` | Fond cartes |
| `--c3` | `#1A2840` | Fond cartes featured |
| `--c4` | `#243558` | Bordures, séparateurs |
| `--c5` | `#2E4470` | Bordures hover |

### Texte commun
| Token | Hex | Usage |
|---|---|---|
| `--ww` | `#F0F6FF` | Titres, texte fort |
| `--w` | `#E8F0F8` | Texte principal |
| `--g3` | `#B8CCE0` | Corps de texte |
| `--g2` | `#8AAAC8` | Texte secondaire |
| `--g1` | `#5A7A9E` | Texte tertiaire, labels |

---

## 04 — Déclinaisons par plateforme

### V2 — Site Web (mrkhiar.com)
**Direction :** Bleu abyssal + dorure épurée

| Token | Hex | Usage |
|---|---|---|
| `--bl-vif` | `#2D6AC4` | Bleu action, CTA secondaire |
| `--bl-mid` | `#4A8FE0` | Labels sections, eyebrows |
| `--bl-lt` | `#6BAEF5` | Accent, logo K, highlights |
| `--bl-pale` | `#9ECAFF` | Tags discrets |
| `--or` | `#B8922A` | **Or épuré — CTA principal uniquement** |
| `--or-lt` | `#D4AE5A` | Or clair — tags premium, highlights éditoriaux |
| `--or-line` | `#8A6B1E` | Or bordure — filets, séparateurs |

**Règle de l'or (V2) :**
L'or n'apparaît que sur 5 types d'éléments :
1. CTA principal "Prendre contact" / "Contact"
2. Tags des offres premium (Vocal Signature, Voix-off Premium, High ticket)
3. Filet vertical des citations éditoriales
4. Highlights texte sur offres premium dans le corps
5. Point de ponctuation footer

Tout le reste → gamme bleue exclusivement.

**Logo V2 :** MRK — le K en `#D4AE5A` (or clair)

---

### V3 — LinkedIn
**Direction :** Bleu intégral — monochrome saphir

Même palette bleue que V2, **zéro or**.

| Hiérarchie | Hex | Usage |
|---|---|---|
| Action forte | `#2D6AC4` | CTA "Se connecter", bordures featued |
| Structure | `#4A8FE0` | Labels, eyebrows, séparateurs |
| Mise en valeur | `#6BAEF5` | Highlights texte, avatar initiales |
| Discret | `#9ECAFF` | Tags secondaires |

**Règle V3 :** Le bleu assure seul toute la hiérarchie. Pas d'accent complémentaire.

**Logo V3 :** MRK — le K en `#6BAEF5` (bleu givré)

---

### V4 — Instagram (Phase 2 · Mois 2–3)
**Direction :** Bleu abyssal + accent grenat-rose

| Token | Hex | Usage |
|---|---|---|
| Accent principal | `#C13584` | Bordures featured, filets |
| Accent clair | `#E880B8` | Highlights, tags premium |
| Fond accent | `#6B1C4A` | Badges, pills colorés |

**Registre :** Émotionnel, visuel, coulisses. Carrousels, Reels, Stories.

**Logo V4 :** MRK — le K en `#E880B8` (rose poudré)

---

### V5 — TikTok (Phase 3 · Mois 4–6)
**Direction :** Bleu abyssal + accent cyan électrique

| Token | Hex | Usage |
|---|---|---|
| Accent principal | `#00BCD4` | Bordures, call-out |
| Accent clair | `#4DD6E8` | Textes animés, titres vidéos |
| Fond accent | `#002830` | Badges |

**Registre :** Pédagogique, direct, court. Vidéo verticale, sous-titres animés.

**Logo V5 :** MRK — le K en `#4DD6E8` (cyan électrique)

---

## 05 — Le K comme marqueur de plateforme

```
MRK (K or #D4AE5A)    →  Site Web     — Autorité premium
MRK (K bleu #6BAEF5)  →  LinkedIn     — Précision professionnelle
MRK (K rose #E880B8)  →  Instagram    — Énergie éditoriale
MRK (K cyan #4DD6E8)  →  TikTok       — Impact immédiat
```

---

## 06 — Composants UI

### Boutons
| Type | Style | Usage |
|---|---|---|
| Primary | Background `--or`, texte `--ww` | CTA de conversion (site uniquement) |
| Secondary | Background `--bl-vif`, texte `--ww` | CTA navigation, "Voir les offres" |
| Ghost | Transparent, bordure `--c4`, texte `--g2` | Actions tertiaires |
| LinkedIn CTA | Background `--or` sur V2, `--bl-vif` sur V3 | "Se connecter" |

### Tags / Pills
| Type | Style | Usage |
|---|---|---|
| Premium (V2) | Bordure `--or-line`, texte `--or-lt` | Offres high ticket, premium |
| Structurel | Background `--c4`, texte `--bl-pale` | Catégories, volume, retainer |
| LinkedIn (V3) | Background `--c3`, bordure `--c5`, texte `--bl-pale` | Compétences, spécialités |

### Bordures & séparateurs
- Épaisseur standard : **0.5px** partout
- Séparateur éditorial or : filet vertical `2px solid --or` (V2 uniquement)
- Séparateur structurel bleu : filet horizontal `0.5px solid --c4`
- Jamais d'ombres portées. Jamais de dégradés.

### Cartes
- Background : `--c2` (standard) ou `--c3` (featured)
- Bordure : `0.5px solid --c4`
- Featured : border-top `2px solid` (or en V2, bleu-vif en V3)
- Border-radius : `2px` (style éditorial carré, non arrondi)

---

## 07 — Règles éditoriales (toutes plateformes)

### Style textuel
- Concis, structuré, sans superlatifs creux
- Autorité sans arrogance
- Zéro phrase creuse : "expert de renom", "leader incontesté" → interdit
- Labels en uppercase, letter-spacing 2–3px, taille 10–11px
- Corps de texte : DM Sans 300, line-height 1.7–1.8

### Hiérarchie de la page
1. Eyebrow (label catégorie) → bleu mid / cyan / rose selon plateforme
2. H1 display → Playfair 700, couleur `--ww`
3. Em d'accentuation → couleur accent plateforme
4. Sous-titre → DM Sans 300, couleur `--g3`
5. CTA → bouton primary

### Ce qui ne s'écrit pas
- Pas de "solutions sur-mesure" ou "accompagnement personnalisé"
- Pas de "je suis passionné par..."
- Pas de listes à puces sans hiérarchie claire
- Pas de contenu mélange-langue dans un même post

---

## 08 — Séquence de déploiement

| Phase | Plateforme | Délai | Objectif |
|---|---|---|---|
| **1 — Maintenant** | Site V2 + LinkedIn V3 | Immédiat | Conversion B2B, crédibilité |
| **2** | Instagram V4 | Mois 2–3 | Notoriété, humanisation |
| **3** | TikTok V5 | Mois 4–6 | Audience large, pédagogie |

---

## 09 — Checklist avant publication (toute plateforme)

- [ ] Le slogan "Voice is an Asset." est présent ou en sous-texte
- [ ] La police display est Playfair Display
- [ ] Le fond est dans la famille bleu abyssal (#060A10 → #1A2840)
- [ ] L'accent couleur correspond à la bonne version (or=site, bleu=LI, rose=IG, cyan=TT)
- [ ] Pas de superlatifs creux dans le texte
- [ ] La langue est cohérente du début à la fin du contenu
- [ ] Zéro mention de "clone vocal" ou stack technique dans les supports publics
- [ ] Le K du logo est dans la couleur accent de la plateforme

---

*MRK — Voice is an Asset. · Design System v1.0 · Avril 2026*
